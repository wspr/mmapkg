_________________
ColorbarPlot v0.3
2007 Oct 26

ColorbarPlot is a function to plot a ContourPlot, DensityPlot or Plot3D with an attached colorbar to indicate the ranges of the function that is being plotted. The syntax is not exactly the same as for the built-in functions. (Perhaps this will change in the future.)

An example file, ColorbarPlot-example.nb, is distributed with this package to demonstrate its use.

This package has been written with and for Mathematica 6. It won't work in previous versions of Mathematica. Who knows if it will work in the future.

Please send comments and suggestions to us both at
  wspr 81 at gmail dot com 
  michael dot p dot croucher at googlemail dot com

Copyright 2007 
Will Robertson & Mike Croucher

_____
To-do

- Horizontal colourbar above or below the plot.
- Support for List-based plots.
- Support for 3D contour/density plots

_______
Changes

v0.2 (WR)

Inset used as a wrapper around the Row to add the colorbar to the plot so that the final output is a proper Graphics object. This allows MathPSfrag usage, for example.

v0.3 (MC)

Added support for Plot3D; tidied up the code a little.

_______
Licence

This package consists of the files ColorbarPlot.m and ColorbarPlot-example.nb. It may be freely distributed and modified under the terms & conditions of the Apache License, v2.0: <http://www.apache.org/licenses/LICENSE-2.0>