(* ::Package:: *)

(* ::Section:: *)
(*Readme*)


(* ::Text:: *)
(*ColorbarPlot v0.3*)
(*2007 Oct 26*)
(**)
(*ColorbarPlot is a function to plot a ContourPlot, DensityPlot or Plot3D with an attached colorbar to indicate the ranges of the function that is being plotted. The syntax is not exactly the same as for the built-in functions. (Perhaps this will change in the future.)*)
(**)
(*An example file, ColorbarPlot-example.nb, is distributed with this package to demonstrate its use.*)
(**)
(*This package has been written with and for Mathematica 6. It won't work in previous versions of Mathematica. Who knows if it will work in the future.*)
(**)
(*Please send comments and suggestions to us both at*)
(*  wspr 81 at gmail dot com *)
(*  michael dot p dot croucher at googlemail dot com*)
(**)
(*Copyright 2007 *)
(*Will Robertson & Mike Croucher*)


(* ::Section:: *)
(*To-do*)


(* ::Text:: *)
(*-- Horizontal colourbar above or below the plot.*)


(* ::Text:: *)
(*-- Support for List-based plots.*)


(* ::Text:: *)
(*-- Support for 3D contour/density plots*)


(* ::Section:: *)
(*Changes*)


(* ::Subsubsection:: *)
(*v0.2 (WR)*)


(* ::Text:: *)
(*Inset used as a wrapper around the Row to add the colorbar to the plot so that the final output is a proper Graphics object. This allows MathPSfrag usage, for example.*)


(* ::Subsubsection:: *)
(*v0.3 (MC)*)


(* ::Text:: *)
(*Added support for Plot3D; tidied up the code a little.*)


(* ::Section:: *)
(*Licence*)


(* ::Text:: *)
(*This package consists of the files ColorbarPlot.m and ColorbarPlot-example.nb. It may be freely distributed and modified under the terms & conditions of the Apache License, v2.0: <http://www.apache.org/licenses/LICENSE-2.0>*)


(* ::Section:: *)
(*Preamble*)


BeginPackage["ColorbarPlot`"];


ColorbarPlot::usage =
"ColorbarPlot[F[#1,#2]&,{Xmin,Xmax},{Ymin,Ymax},<options>]:
Creates a DensityPlot or a ContourPlot or a 3DPlot of the
function F with an attached colorbar to denote its range.

Please see the documentation for a description of the 
possible options.";


Begin["`Private`"]


(* ::Section:: *)
(*Package*)


Options[ColorbarPlot]={
(* general: *)
  Colors   -> "LakeColors",
  PlotType -> DensityPlot,
(* for the plot: *)
  XLabel   -> "",
  YLabel   -> "",
  ZLabel   -> "",
  Title    -> "",
  Height   -> 8*72/2.54,
(* for the colorbar: *)
  CLabel   -> "",
  CTicks   -> All,
  CTickSide-> Left,
  CSide    -> Right,
  ColorbarOpts -> {}
};


ColorbarPlot[function_,{___,x1_,x2_},{___,y1_,y2_},
             opts:OptionsPattern[]] := Module[
  (* local variables *)
  {max = -Infinity, min = Infinity, dimension = 2,
   Opt,monitor,ft,contours,frameticks,cside,
   plot,colorbar,bartype,labels},

  (* Option processing 
    (filter out options for the plot itself) *)
  Opt[x_] := OptionValue[ColorbarPlot,
         FilterRules[{opts},Options[ColorbarPlot]],x];
  PlotOpt[x_] := OptionValue[Opt[PlotType],
         FilterRules[{opts},Options[Opt[PlotType]]],x];

  (* Define a function from the input that records the 
     maxima and minima of the function as it is evaluated.
     This information is then used to generate the colorbar: *)
  monitor[x__] := 
    Module[{val=function[x]},
      min = Min[min,val];
      max = Max[max,val];
      val];

  (* Plot type processing *)
  If[Evaluate@Opt[PlotType]===ContourPlot,
    dimension = 2;
    If[Head[Evaluate@PlotOpt[Contours]]===List,
       ft := PlotOpt[Contours],
       ft := Opt[CTicks]];
    contours := Contours -> PlotOpt[Contours];, 
    (* else: *)
    ft := Opt[CTicks];
    contours := {};];

  If[Evaluate@Opt[PlotType]===DensityPlot,
    dimension = 2;
  ];
  
  If[Evaluate@Opt[PlotType]===Plot3D,
    dimension = 3;
  ];

  (* Set the type of colorbar *)
  If[dimension==2,
    bartype = Opt[PlotType],
    (* else force DensityPlot for 3D plots *)
    bartype = DensityPlot
  ];

  (* Set the labels appropriately for 2D or 3D: *)
  If[dimension==3,
    labels = {PlotLabel -> Opt[Title],
            AxesLabel -> {Opt[XLabel],Opt[YLabel],Opt[ZLabel]}};,
  (* else *)
    labels = FrameLabel -> {{Opt[YLabel],None},
                            {Opt[XLabel],Opt[Title]}};
  ];

  (* Colorbar side and ticks location *)
  If[Evaluate@Opt[CTickSide]===Right,
    frameticks = {None,ft},
    (* else *)
    frameticks = {ft,None}
    ];
  If[Evaluate@Opt[CSide]===Left,
    cside := Reverse,
    (* else *)
    cside := Identity
    ];

  (* Construct plot *)
  plot=Opt[PlotType][
    monitor[x,y],{x,x1,x2},{y,y1,y2},
    Evaluate[FilterRules[{opts},Options[Opt[PlotType]]]],
    PlotRange -> Full,
    ImageSize -> {Automatic,Opt[Height]},
    ColorFunction -> Opt[Colors],
    Evaluate@Sequence@labels
  ];

  (* Construct colorbar *)
  colorbar=bartype[
    y,{x,0,1},{y,min,max},
    Evaluate@Sequence@Opt[ColorbarOpts],
    ImageSize -> {Automatic,Opt[Height]},
    ColorFunction -> Opt[Colors],
    Evaluate@Sequence@contours,
    PlotRange -> Full,
    AspectRatio -> 10,
    PlotRangePadding -> 0,
    FrameLabel -> {{"",""},{"",Opt[CLabel]}},
    (* the empty frame tick here is 
       to align the colorbar with the plot: *)
    FrameTicks -> {frameticks,{{{0,""}},None}}
  ];
    
  (* Draw the plot and colorbar next to each other *)
  Graphics[{Inset[Row[
      cside@{plot,colorbar}
    ],{0,0},Center]},
    ImageSize -> {Automatic,Opt[Height]}]
]
  


(* ::Section:: *)
(*End*)


End[];
EndPackage[];
