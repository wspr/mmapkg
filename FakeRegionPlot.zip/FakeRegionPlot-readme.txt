FakeRegionPlot v0.1
2007 Nov 21

Creates a RegionPlot using contiguous, rather than overlapping,
regions. This allows export to EPS directly without having 
transparent colours destroyed (or rather, made fully opaque) 
in the process.

This package has been written with and for Mathematica 6. 
It won't work in previous versions of Mathematica. Who knows
if it will work in the future.

Please send comments and suggestions to wspr 81 at gmail dot com.

Copyright 2007 
Will Robertson

TODO
- Better default colours (match RegionPlot)
- I doubt that all PlotStyle/BoundaryStyle options are supported.

LICENSE
This package consists of the files FakeRegionPlot.m and FakeRegionPlot-example.nb. It may be freely distributed 
and modified under the terms & conditions of the Apache 
License, v2.0: <http://www.apache.org/licenses/LICENSE-2.0>