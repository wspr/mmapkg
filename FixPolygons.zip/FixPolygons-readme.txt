________________
FixPolygons v0.1
2007 Oct 15

This package provides a function of the same name to improve a 
Contour or Region plot by removing all extraneous polygons.

Such 2D region plots create very complicated graphics based on the 
mesh used to generate the output; these can be simplified with 
an improvement in quality and a decrease in filesize.

Examples and some documentation of the algorithm are shown 
in the supplementary file FixPolygons-example.nb.

This function is very inefficient! I wrote it rather hastily and it
needs optimisation. Please send comments and suggestions to 
wspr 81 at gmail dot com.

Copyright 2007 
Will Robertson

This package consists of the files FixPolygons.m and FixPolygons-example.nb. 
It may be freely distributed and modified under the terms & conditions of the Apache License, v2.0:
   <http://www.apache.org/licenses/LICENSE-2.0>