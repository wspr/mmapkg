(* ::Package:: *)

(* ::Section:: *)
(*Readme*)


(* ::Text:: *)
(*FixPolygons v0.1*)
(*2007 Oct 15*)
(**)
(*This package provides a function of the same name to improve a *)
(*Contour or Region plot by removing all extraneous polygons.*)
(**)
(*Such 2D region plots create very complicated graphics based on the *)
(*mesh used to generate the output; these can be simplified with *)
(*an improvement in quality and a decrease in filesize.*)
(**)
(*Examples and some documentation of the algorithm are shown *)
(*in the supplementary file FixPolygons-example.nb.*)
(**)
(*This function is very inefficient! I wrote it rather hastily and it*)
(*needs optimisation. Please send comments and suggestions to *)
(*wspr 81 at gmail dot com.*)
(**)
(*Copyright 2007 *)
(*Will Robertson*)
(**)
(*This package consists of the files FixPolygons.m and FixPolygons-example.nb. *)
(*It may be freely distributed and modified under the terms & conditions of the Apache License, v2.0:*)
(*   <http://www.apache.org/licenses/LICENSE-2.0>*)


(* ::Section:: *)
(*Package*)


(* ::Subsection:: *)
(*Intro*)


BeginPackage["FixPolygons`"];


FixPolygons::usage =
"FixPolygons[ <graphic> ]:
  Joins all contiguous polygons into a single shape. 
  This can dramatically improve the image quality and 
  decrease the file size of a ContourPlot or RegionPlot.";


Begin["`Private`"]


(* ::Subsection:: *)
(*Code*)


LinesFromPoly[list_List] := 
  Partition[Riffle[list,list]//RotateLeft,2]
LinesFromPoly[lists__] := LinesFromPoly /@ {lists}


PolyFromLines[list_List] :=
  Flatten[list] //. {b___,a_,a_,c___} -> {b,a,c};


MergeLine[list_,item_] := Module[{p},
  p=Position[list,Reverse[item],1];
  If[Length[p]===0,
  (* new line is not already accounted for: *)
    p=Position[list[[All,2]],item[[1]],1];
    If[Length[p]===0,
    (* dont prepend; maybe append? *)
      p=Position[list[[All,1]],item[[2]],1];
      If[Length[p]===0,
        (* nowhere to go *)
        p=Length[list]+1,
        (* found a spot *)
        p=p[[1,1]]
      ],
      (* found a spot *)
      p=p[[1,1]]+1
    ];
    Insert[list,item,p],
    (* new line needs to be removed: *)
    Delete[list,p[[1]]]
  ]
]


MergeLines[list_,new_] := Fold[MergeLine,list,new]


MergePolygon[a_,b_] := MergeLines[a,LinesFromPoly[b]]
MergePolygons[{head_,tail__}]:=
  Fold[MergePolygon,LinesFromPoly[head],{tail}]


MergeMerge[in_,R_] := Module[{out,l,f,p},
  If[R < Length[in],
    out = RotateRight[in,R];
    l = out[[1,-1,2]]; (* the last pair element of the first list of pairs *)
    f = out[[2;;-1,1,1]]; (* the first pair elements of the rest of the list *)
    p = Position[f,l]; (* if two lists should join... *)
    If[Length[p]!=0,
    (* at least one match *)
      p = p[[1,1]]+1; (* this is 2nd list *)
      out[[1]] = Join[out[[1]],out[[p]]]; (* append it to the first ... *)
      out = Delete[out,p]; (* ... and delete it from the list*)
      MergeMerge[out,R], (* iterate! *)
    (* no more matches *)
      in
  (* we've already iterated through the list *)
  ],in]];


JoinEndpoints[head_, tail_] := 
  Join[{{head[[1,1]],tail[[1,1]]}},
       tail,
       {{tail[[1,1]],head[[1,1]]}}]


DisparateJoin[head_] := head
DisparateJoin[head_, tail_] :=
  {head,JoinEndpoints[head,tail]}
DisparateJoin[head_, tails__] :=
  {head,JoinEndpoints[head,#]&/@{tails}}


MergeAll[ppp_] := Block[{tmp,$RecursionLimit=Infinity},
  tmp = Split[MergePolygons[ppp], #1[[2]] == #2[[1]]&];
  tmp = Fold[MergeMerge, tmp, Range[Length[tmp]-1]];
  tmp = DisparateJoin @@ tmp;
  PolyFromLines[tmp]]


FixPolygons[graf_] :=
  graf //. {Polygon[{a__},c___],
            Polygon[{b__},c___],d___} ->
           {Polygon[{a,b},c],d} /. 
           {Polygon[{ab__},c___],d___} :>
           {Polygon[MergeAll[{ab}],c],d};


(* ::Subsection::Closed:: *)
(*End*)


End[];
EndPackage[];
